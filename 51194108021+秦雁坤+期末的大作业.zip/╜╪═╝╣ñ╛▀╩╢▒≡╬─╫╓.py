import sys
from time import sleep
from tkinter import*
from tkinter import filedialog
import PyHook3
import pythoncom
import  codecs
from PIL import Image,ImageGrab

import configparser
from aip import AipOcr

import  codecs
import os
sys.path.append('C:\\Users\\13284\\Anaconda3\\pkgs\\baidu_aip-2.2.18.0.dist-info')

sys.path.append('C:\\Users\\13284\\Anaconda3\\pkgs')

hookm=PyHook3.HookManager()

def ScreenShoot():
    hookm.MouseLeftDown = OnmouseDownEvent
    hookm.MouseLeftUp = OnmouseUpEvent
    hookm.HookMouse()
def OnmouseDownEvent(event):
    global qidian_x
    global qidian_y
    qidian_x,qidian_y = event.Position
    return True

def OnmouseUpEvent(event):
    
    end_x,end_y = 0,0
    end_x,end_y = event.Position
    hookm.UnhookMouse()
    im = (qidian_x,qidian_y,end_x,end_y) 

    screen1= ImageGrab.grab(im)
    screen1.save(r'imageGrab.png') 
    root.quit()  
    return True

def ScreenShootAllGraph():
    
    root.wm_minsize(0,0)
    screen1= ImageGrab.grab()
    screen1.save(r'imageGrab.png') 
    root.quit()     
root = Tk()
root.title("截图")
root.geometry('500x500')  
root.resizable(width=True, height=True) 
 
bt_ScreenShot = Button(root,text="截取部分图片",command=ScreenShoot)
bt_ScreenShot.place(width=90,height=30,x=20,y=300)
 

bn_ScreenAllShot = Button(root,text="截取全图",command=ScreenShootAllGraph)
bn_ScreenAllShot.place(width=90,height=30,x=130,y=300)
 
root.mainloop()
def ocr(path):
    with open(path,'rb') as f:
        return  f.read()
def main():
    filename = "imageGrab.png"
    print("成功截图，正在识别图片中的文字，请等待，到TXT中查看")
    app_id = '16193547'
    api_key = 'B0R5gbezdGSzCY4oIlOpuLy8'
    secret_key = 'CyevG1PTfpPvkw9vwItPdya09GrzZ462'
    client = AipOcr(app_id,api_key,secret_key)

    image = ocr(filename)

    dict1 = client.general(image)

    with codecs.open(filename + ".txt","w","utf-8") as f:
        for i in dict1["words_result"]:
            f.write(str(i["words"] + "\r\n"))
    print ("已成功导出文字")
if __name__ == '__main__':
    ScreenShoot()
    main()


